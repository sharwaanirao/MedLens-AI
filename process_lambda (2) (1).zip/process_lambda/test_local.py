from lambdas.process_lambda.handler import lambda_handler

# Fake event simulating S3 file
event = {
    "bucket": "local-test",
    "key": "sample_report.txt"
}

# Call Lambda handler
response = lambda_handler(event, None)

print("==== AI JSON Output ====")
print(response)