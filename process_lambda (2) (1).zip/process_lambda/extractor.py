"""PDF text extraction for the Process Lambda."""
from __future__ import annotations

import io


class ExtractionError(Exception):
    """Raised when no readable text can be extracted from a PDF."""

    def __init__(self, message: str = "No readable text found in PDF") -> None:
        super().__init__(message)
        self.message = message


def extract_text(pdf_bytes: bytes) -> str:
    """Extract all readable text from a PDF.

    Args:
        pdf_bytes: Raw PDF file content.

    Returns:
        Extracted text with paragraph structure preserved where possible.

    Raises:
        ExtractionError: If no text can be extracted (e.g. image-only PDF).
    """
    try:
        from pypdf import PdfReader  # type: ignore
    except ImportError as exc:
        raise ExtractionError("pypdf is not installed") from exc

    reader = PdfReader(io.BytesIO(pdf_bytes))

    parts: list[str] = []
    for page in reader.pages:
        page_text = page.extract_text() or ""
        stripped = page_text.strip()
        if stripped:
            parts.append(stripped)

    if not parts:
        raise ExtractionError(
            "Your report could not be read. Please ensure it is a text-based PDF."
        )

    return "\n\n".join(parts)
