"""Process Lambda handler — text extraction + Bedrock analysis."""
from __future__ import annotations

import json
import os
import sys

import boto3
from botocore.exceptions import BotoCoreError, ClientError

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from shared.models import Insight

from extractor import ExtractionError, extract_text
from bedrock import build_prompt, parse_insight

_S3_BUCKET = os.environ.get("S3_BUCKET_NAME", "")
_BEDROCK_MODEL_ID = os.environ.get(
    "BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0"
)


def _log_error(stage: str, message: str, **extra) -> None:
    """Emit a structured JSON error log to stdout (captured by CloudWatch)."""
    record = {"level": "ERROR", "stage": stage, "message": message, **extra}
    print(json.dumps(record))


def handler(event: dict, context) -> dict:
    """Lambda entry point.

    Args:
        event: ``{ "reportId": str }``
        context: Lambda context object (unused).

    Returns:
        ``{ "insight": <insight dict> }`` on success, or
        ``{ "error": { "stage": str, "message": str } }`` on failure.
    """
    report_id: str = event.get("reportId", "")

    # ------------------------------------------------------------------ #
    # 1. Retrieve PDF from S3                                              #
    # ------------------------------------------------------------------ #
    s3 = boto3.client("s3")
    object_key = f"reports/{report_id}.pdf"

    try:
        s3_response = s3.get_object(Bucket=_S3_BUCKET, Key=object_key)
        pdf_bytes: bytes = s3_response["Body"].read()
    except (ClientError, BotoCoreError) as exc:
        _log_error("extraction", str(exc), reportId=report_id, key=object_key)
        return {
            "error": {
                "stage": "extraction",
                "message": f"Could not retrieve report from storage: {exc}",
            }
        }

    # ------------------------------------------------------------------ #
    # 2. Extract text                                                      #
    # ------------------------------------------------------------------ #
    try:
        extracted_text = extract_text(pdf_bytes)
    except ExtractionError as exc:
        _log_error("extraction", exc.message, reportId=report_id)
        return {
            "error": {
                "stage": "extraction",
                "message": "Your report could not be read. Please ensure it is a text-based PDF.",
            }
        }

    # ------------------------------------------------------------------ #
    # 3. Invoke Bedrock                                                    #
    # ------------------------------------------------------------------ #
    bedrock = boto3.client("bedrock-runtime")
    prompt_body = build_prompt(extracted_text)

    try:
        bedrock_response = bedrock.invoke_model(
            modelId=_BEDROCK_MODEL_ID,
            body=json.dumps(prompt_body),
            contentType="application/json",
            accept="application/json",
        )
        raw_body = json.loads(bedrock_response["body"].read())
    except (ClientError, BotoCoreError) as exc:
        _log_error("analysis", str(exc), reportId=report_id, modelId=_BEDROCK_MODEL_ID)
        return {
            "error": {
                "stage": "analysis",
                "message": "AI analysis could not be completed. Please try again.",
            }
        }

    # ------------------------------------------------------------------ #
    # 4. Parse Insight                                                     #
    # ------------------------------------------------------------------ #
    try:
        insight: Insight = parse_insight(raw_body, report_id)
    except (KeyError, ValueError, json.JSONDecodeError) as exc:
        _log_error("analysis", str(exc), reportId=report_id)
        return {
            "error": {
                "stage": "analysis",
                "message": "AI analysis could not be completed. Please try again.",
            }
        }

    # ------------------------------------------------------------------ #
    # 5. Return success                                                    #
    # ------------------------------------------------------------------ #
    return {
        "insight": {
            "reportId": insight.reportId,
            "simpleExplanation": insight.simpleExplanation,
            "riskIndicators": [
                {"description": ri.description, "severity": ri.severity}
                for ri in insight.riskIndicators
            ],
            "importantValues": [
                {
                    "name": iv.name,
                    "result": iv.result,
                    "referenceRange": iv.referenceRange,
                    "status": iv.status,
                }
                for iv in insight.importantValues
            ],
            "doctorQuestions": insight.doctorQuestions,
        }
    }
if __name__ == "__main__":
    import os
    from extractor import extract_text, ExtractionError
    from bedrock import parse_insight  # mock parse_insight returns a dict

    # PDF file in the same folder as handler.py
    sample_pdf = "sample.pdf"

    # Check file exists
    if not os.path.exists(sample_pdf):
        print({"error": {"stage": "local_test", "message": f"{sample_pdf} not found"}})
        exit()

    # Read PDF bytes
    with open(sample_pdf, "rb") as f:
        pdf_bytes = f.read()

    # Extract text
    try:
        extracted_text = extract_text(pdf_bytes)
    except ExtractionError as exc:
        print({"error": {"stage": "extraction", "message": str(exc)}})
        exit()

    # Mock Bedrock response for local testing
    bedrock_response = {
        "content": {
            "simpleExplanation": "This is a sample explanation from the PDF.",
            "riskIndicators": [],
            "importantValues": [],
            "doctorQuestions": ["Sample question 1?", "Sample question 2?", "Sample question 3?"]
        }
    }

    # Parse insight (returns dict)
    try:
        insight = parse_insight(bedrock_response, report_id="local_test")
    except Exception as exc:
        print({"error": {"stage": "analysis", "message": str(exc)}})
        exit()

    # Build final result
    result = {
        "reportId": insight["reportId"],
        "conditions": [
            {"name": "Condition A", "confidence": "85%", "reasoning": "Matches patient history."},
            {"name": "Condition B", "confidence": "70%", "reasoning": "Symptoms partially match."},
            {"name": "Condition C", "confidence": "60%", "reasoning": "Rare but possible based on dataset."}
        ],
        "simpleExplanation": insight["simpleExplanation"],
        "riskIndicators": insight.get("riskIndicators", [{"description": "Sample risk indicator", "severity": "low"}]),
        "importantValues": insight.get("importantValues", [{"name": "Sample Value", "result": "123", "referenceRange": "100-200", "status": "within"}]),
        "doctorQuestions": insight.get("doctorQuestions", [])
    }

    print(result)