from types import SimpleNamespace

def build_prompt(extracted_text: str) -> dict:
    """Mock build_prompt for local testing."""
    return {"prompt": extracted_text}

def parse_insight(bedrock_response: dict, report_id: str):
    """Return a dummy Insight object for local testing (no AWS needed)."""

    class DummyRiskIndicator:
        description = "Sample risk indicator"
        severity = "low"

    class DummyImportantValue:
        name = "Sample Value"
        result = "123"
        referenceRange = "100-200"
        status = "within"

    # Build the dummy output inside the function
    output = {
        "reportId": report_id,
        "conditions": [
            {"name": "Condition A", "confidence": "85%", "reasoning": "Matches patient history."},
            {"name": "Condition B", "confidence": "70%", "reasoning": "Symptoms partially match."},
            {"name": "Condition C", "confidence": "60%", "reasoning": "Rare but possible based on dataset."}
        ],
        "simpleExplanation": bedrock_response.get("content", {}).get("simpleExplanation", "Dummy explanation"),
        "riskIndicators": [
            {"description": ri.description, "severity": ri.severity} 
            for ri in bedrock_response.get("riskIndicators", [])
        ] or [{"description": "Sample risk indicator", "severity": "low"}],
        "importantValues": [
            {"name": iv.name, "result": iv.result, "referenceRange": iv.referenceRange, "status": iv.status}
            for iv in bedrock_response.get("importantValues", [])
        ] or [{"name": "Sample Value", "result": "123", "referenceRange": "100-200", "status": "within"}],
        "doctorQuestions": bedrock_response.get("doctorQuestions", [
            "Sample question 1?", "Sample question 2?", "Sample question 3?"
        ])
    }

    return output  # ✅ return is now properly inside the function